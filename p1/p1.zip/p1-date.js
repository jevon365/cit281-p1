/*
    CIT 281 Project 1
    Name: Jevon Owen-Kennedy
*/

let days = ["sunday","mondat","tuesday",'wensday','thursday','friday','saterday']
let day = new Date();
let today = days[day.getDay()];
console.log(today)